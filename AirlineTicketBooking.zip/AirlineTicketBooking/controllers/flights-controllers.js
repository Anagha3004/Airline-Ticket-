const express = require('express');
const {v4 : uuidv4} = require('uuid');
const{validationResult} = require('express-validator');
const HttpError = require('../model/http-error');
const flight = require('../model/flights');
const User = require('../model/User');
const mongoose = require('mongoose');
const { Airline,Flight } = require('../model/flights');
const {FlightDetail} = require('../model/flights')

const getAllFlights = async (req, res, next) => {
    console.log("GET Request to fetch all flights");

    let flights; // Use plural to reflect multiple flights
    try {
        flights = await Flight.find(); // Fetch all flights from the database
         
    } catch (err) {
        console.error('Error fetching flights:', err); // Log the error for debugging
        return next(new HttpError('Something went wrong, could not retrieve flights.', 500));
    }

    if (!flights || flights.length === 0) {
        return res.status(404).json({ message: 'No flights found.' });
    }

    res.json({ flights: flights.map(flight => flight.toObject({ getters: true })) });
};

//get flight by flightid
const getFlightById = async (req, res, next) => {
    console.log("GET Request in flight");
    const flightid = req.params.fid;

    let flight;
    let flightDetails;
    try {
        flight = await Flight.findById(flightid); 
        flightDetails = await FlightDetail.findOne({ Flight_id: flightid });
    } catch (err) {
        const error = new HttpError('Something went wrong, could not find a flight.', 500);
        return next(error);
    }

    if (!flight || !flightDetails) {
        return next(new HttpError('Could not find a flight or its details with the given id.', 404));
    }

    res.json({
        flight: flight.toObject({ getters: true }),
        flightDetails: flightDetails.toObject({ getters: true })
    });
};



const createFlight = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors.array());
        return next(new HttpError('Invalid inputs passed, please check your data.', 422));
    }
    console.log(req.body); 

    const { 
        name, 
        airline_id, 
        departure_airport, 
        arrival_airport, 
        departure_time, 
        arrival_time, 
        travel_duration,
        Totalseats,
        economyseatprice,
        economyseatsavailable,
        firstclassseatprice,
        firstclassseatsavailable,
        businessseatprice,
        businessseatsavailable,
        foodavailable,
        luggage
    } = req.body;

    let sess;
    try {
        sess = await mongoose.startSession();
        sess.startTransaction();

        // Create a new flight
        const newFlight = new Flight({
            name,
            airline_id,
            departure_airport,
            arrival_airport,
            departure_time,
            arrival_time,
            travel_duration
        });

        // Save the flight
        await newFlight.save({ session: sess });

        // Find the airline and push the flight ID to its 'flights' array
        const airline = await Airline.findById(airline_id).session(sess);
        if (!airline) {
            return next(new HttpError('Airline not found.', 404));
        }

        airline.flights.push(newFlight._id);  // Add flight ID to the airline's flights array
        await airline.save({ session: sess });  // Save the updated airline

        // Create a new FlightDetail document
        const flightDetail = new FlightDetail({
            Flight_id: newFlight._id, // Reference to the newly created flight
            Totalseats,
            economyseatprice,
            economyseatsavailable,
            firstclassseatprice,
            firstclassseatsavailable,
            businessseatprice,
            businessseatsavailable,
            foodavailable,
            luggage
        });

        // Save the flight detail
        await flightDetail.save({ session: sess });

        // Commit the transaction
        await sess.commitTransaction();
        res.status(201).json({ flight: newFlight, flightDetail });
    } catch (err) {
        if (sess) await sess.abortTransaction();  // Roll back the transaction if an error occurs
        console.error('Error creating flight:', err);
        return next(new HttpError('Creating flight failed, please try again.', 500));
    } finally {
        if (sess) sess.endSession();  // Ensure the session is properly ended
    }
};


const updateFlight = async (req, res, next) => {
    const flightId = req.params.fid;
    const {
        name,
        departure_time,
        arrival_time,
        Totalseats,
        economyseatprice,
        economyseatsavailable,
        firstclassseatprice,
        firstclassseatsavailable,
        businessseatprice,
        businessseatsavailable,
        foodavailable,
        luggage
    } = req.body;

    let flight;
    let flightDetail;
    let sess;

    try {
        sess = await mongoose.startSession();
        sess.startTransaction();

        // Find and update the flight
        flight = await Flight.findById(flightId).session(sess);
        if (!flight) {
            return next(new HttpError('Flight not found', 404));
        }

        flight.name = name || flight.name;
        flight.departure_time = departure_time || flight.departure_time;
        flight.arrival_time = arrival_time || flight.arrival_time;

        await flight.save({ session: sess });

        // Find and update the flight details
        flightDetail = await FlightDetail.findOne({ Flight_id: flightId }).session(sess);
        if (!flightDetail) {
            return next(new HttpError('Flight details not found', 404));
        }

        flightDetail.Totalseats = Totalseats || flightDetail.Totalseats;
        flightDetail.economyseatprice = economyseatprice || flightDetail.economyseatprice;
        flightDetail.economyseatsavailable = economyseatsavailable || flightDetail.economyseatsavailable;
        flightDetail.firstclassseatprice = firstclassseatprice || flightDetail.firstclassseatprice;
        flightDetail.firstclassseatsavailable = firstclassseatsavailable || flightDetail.firstclassseatsavailable;
        flightDetail.businessseatprice = businessseatprice || flightDetail.businessseatprice;
        flightDetail.businessseatsavailable = businessseatsavailable || flightDetail.businessseatsavailable;
        flightDetail.foodavailable = foodavailable || flightDetail.foodavailable;
        flightDetail.luggage = luggage || flightDetail.luggage;

        await flightDetail.save({ session: sess });

        // Commit the transaction
        await sess.commitTransaction();
        res.status(200).json({ flight: flight.toObject({ getters: true }), flightDetail: flightDetail.toObject({ getters: true }) });
    } catch (err) {
        if (sess) await sess.abortTransaction();  // Roll back the transaction if an error occurs
        console.error('Error updating flight:', err);
        return next(new HttpError('Updating flight failed, please try again.', 500));
    } finally {
        if (sess) sess.endSession();  // Ensure the session is properly ended
    }
};
const deleteFlight = async (req, res, next) => {
    const flightId = req.params.fid;

    let flight;
    let flightDetail;
    let sess;

    try {
        sess = await mongoose.startSession();
        sess.startTransaction();

        // Find the flight and populate the airline to access the flights array
        flight = await Flight.findById(flightId).session(sess).populate('airline_id');
        if (!flight) {
            return next(new HttpError('Could not find the flight for this ID.', 404));
        }

        // Find the associated flight details
        flightDetail = await FlightDetail.findOne({ Flight_id: flightId }).session(sess);
        if (!flightDetail) {
            console.warn('No flight detail found for this flight.');
        }

        // Delete the flight
        await Flight.deleteOne({ _id: flightId }, { session: sess });

        // Remove flight ID from the airline's flights array, if the airline exists
        if (flight.airline_id) {
            flight.airline_id.flights.pull(flight._id);  // Pull removes the flight ID from the array
            await flight.airline_id.save({ session: sess });  // Save the updated airline
        } else {
            console.warn('Airline ID is null, cannot update flights reference.');
        }

        // Delete the flight details if they exist
        if (flightDetail) {
            await FlightDetail.deleteOne({ Flight_id: flightId }, { session: sess });
        }

        // Commit the transaction
        await sess.commitTransaction();
        res.status(200).json({ message: 'Flight and its details deleted successfully' });
    } catch (err) {
        if (sess) await sess.abortTransaction();  // Roll back the transaction if an error occurs
        console.error('Error during flight deletion:', err);
        return next(new HttpError('Something went wrong while deleting the flight...', 500));
    } finally {
        if (sess) sess.endSession();  // Ensure the session is properly ended
    }
};


// Creating (posting) a new flight detail
const createFlightDetail = async (req, res) => {
    try {
        const {
            Flight_id,
            Totalseats,
            economyseatprice,
            economyseatsavailable,
            firstclassseatprice,
            firstclassseatsavailable,
            businessseatprice,
            businessseatsavailable,
           
            foodavailable,
            luggage
        } = req.body;

        // Validate the input fields
        if (!Flight_id || !Totalseats || !economyseatprice || !economyseatsavailable ||
            !firstclassseatprice || !firstclassseatsavailable || !businessseatprice ||
            !businessseatsavailable || !foodavailable || !luggage) {
            return res.status(400).json({ message: "All required fields must be provided" });
        }

        // Create a new FlightDetail document
        const flightDetail = new FlightDetail({
            Flight_id,
            Totalseats,
            economyseatprice,
            economyseatsavailable,
            firstclassseatprice,
            firstclassseatsavailable,
            businessseatprice,
            businessseatsavailable,
            
            foodavailable,
            luggage
        });

        // Save to the database
        await flightDetail.save();

        res.status(201).json({
            message: "Flight detail created successfully",
            flightDetail
        });
    } catch (error) {
        console.error("Error creating flight detail:", error);
        res.status(500).json({ message: "Server error" });
    }
};

// Updating flight detail
const updateFlightDetail = async (req, res, next) => {
    const flightDetailId = req.params.fid;
    const {
        Totalseats,
        economyseatprice,
        economyseatsavailable,
        firstclassseatprice,
        firstclassseatsavailable,
        businessseatprice,
        businessseatsavailable,
        foodavailable,
        luggage
    } = req.body;

    let flightDetail;
    try {
        flightDetail = await FlightDetail.findById(flightDetailId);
    } catch (err) {
        const error = new HttpError('Could not find flight detail with the provided ID.', 500);
        return next(error);
    }

    if (!flightDetail) {
        return next(new HttpError('No flight detail found with the provided ID.', 404));
    }

    // Update only the fields provided in the request body
    flightDetail.Totalseats = Totalseats || flightDetail.Totalseats;
    flightDetail.economyseatprice = economyseatprice || flightDetail.economyseatprice;
    flightDetail.economyseatsavailable = economyseatsavailable || flightDetail.economyseatsavailable;
    flightDetail.firstclassseatprice = firstclassseatprice || flightDetail.firstclassseatprice;
    flightDetail.firstclassseatsavailable = firstclassseatsavailable || flightDetail.firstclassseatsavailable;
    flightDetail.businessseatprice = businessseatprice || flightDetail.businessseatprice;
    flightDetail.businessseatsavailable = businessseatsavailable || flightDetail.businessseatsavailable;
    flightDetail.foodavailable = foodavailable || flightDetail.foodavailable;
    flightDetail.luggage = luggage || flightDetail.luggage;

    try {
        await flightDetail.save();
    } catch (err) {
        const error = new HttpError('Updating flight detail failed, please try again later.', 500);
        return next(error);
    }

    res.status(200).json({ flightDetail });
};
const createAirline = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return next(new HttpError('Invalid inputs passed, please check your data.', 422));
    }

    const { id, name, serviceCode } = req.body;

    if (!serviceCode) {
        return next(new HttpError('Service Code is required to create an airline.', 401));
    }

    const newAirline = new Airline({
        id,
        name,
        serviceCode, // Use serviceCode directly as a string
        flights: []
    });

    try {
        await newAirline.save();
        res.status(201).json({ airline: newAirline });
    } catch (err) {
        console.error("Error creating airline:", err);
        const error = new HttpError('Creating airline failed, please try again later.', 500);
        next(error);
    }
};

const getAirlineAndFlights = async (req, res, next) => {
    try {
        const { serviceCode } = req.body;

        if (!serviceCode) {
            return res.status(400).json({ message: 'Service code missing.' });
        }

        const airline = await Airline.findOne({ serviceCode }).populate('flights');

        if (!airline) {
            return res.status(404).json({ message: 'No airline found. Please create one.' });
        }

        res.status(200).json({ airline });
    } catch (err) {
        console.error('Error fetching airline and flights:', err);
        return res.status(500).json({ message: 'Fetching airline and flights failed, please try again.' });
    }
};

const getFlightsByAirlineId = async (req, res, next) => {
    const airlineId = req.params.airlineId;  // Change this line

    try {
        // Fetch flights that belong to the specified airline ID
        const flights = await Flight.find({ airline_id: airlineId }).populate('airline_id');
        
        if (!flights || flights.length === 0) {
            return next(new HttpError('No flights found for this airline.', 404));
        }

        res.status(200).json({ flights });
    } catch (err) {
        console.error('Error fetching flights:', err);
        return next(new HttpError('Fetching flights failed, please try again.', 500));
    }
};

// Update flight details
const updateFlightById = async (req, res, next) => {
    const flightId = req.params.id;
    const { name, departure_airport, arrival_airport, departure_time, arrival_time, travel_duration } = req.body;

    try {
        const updatedFlight = await Flight.findByIdAndUpdate(
            flightId,
            { name, departure_airport, arrival_airport, departure_time, arrival_time, travel_duration },
            { new: true }
        );

        if (!updatedFlight) {
            return next(new HttpError('Could not find a flight with this ID.', 404));
        }

        res.status(200).json({ flight: updatedFlight });
    } catch (err) {
        console.error('Error updating flight:', err);
        return next(new HttpError('Updating flight failed, please try again.', 500));
    }
};

// Delete flight by ID
const deleteFlightById = async (req, res, next) => {
    const flightId = req.params.id;

    try {
        const flight = await Flight.findByIdAndRemove(flightId);

        if (!flight) {
            return next(new HttpError('Could not find a flight with this ID.', 404));
        }

        res.status(200).json({ message: 'Flight deleted successfully.' });
    } catch (err) {
        console.error('Error deleting flight:', err);
        return next(new HttpError('Deleting flight failed, please try again.', 500));
    }
};


const getAllFlightDetails = async (req, res, next) => {
    try {
        // Fetch all flights and populate airline details
        const flights = await Flight.find()
            .populate('airline_id', 'name serviceCode')
            .lean();

        if (!flights || flights.length === 0) {
            return res.status(404).json({ message: 'No flights found.' });
        }

        // Fetch FlightDetails for each flight
        const flightDetailsPromises = flights.map(async (flight) => {
            const flightDetails = await FlightDetail.findOne({ Flight_id: flight._id }).lean();
            return {
                flight: flight,
                details: flightDetails
            };
        });

        const flightDetailsWithData = await Promise.all(flightDetailsPromises);

        res.json({
            flights: flightDetailsWithData
        });
    } catch (err) {
        console.error('Error fetching flight details:', err);
        return next(new HttpError('Something went wrong, could not retrieve flight details.', 500));
    }
};


exports.getAllFlightDetails=getAllFlightDetails;
exports.getAllFlights = getAllFlights;
exports.getFlightById = getFlightById;
exports.createFlight = createFlight;
exports.updateFlight = updateFlight;
exports.deleteFlight = deleteFlight;
exports.createAirline= createAirline;
exports.getAirlineAndFlights = getAirlineAndFlights;
exports.createFlightDetail=createFlightDetail;
exports.updateFlightDetail=updateFlightDetail;
exports.getFlightsByAirlineId = getFlightsByAirlineId;
exports.updateFlightById = updateFlightById;
exports.deleteFlightById = deleteFlightById;