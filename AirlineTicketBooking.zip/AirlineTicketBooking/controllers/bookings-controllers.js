const express = require('express');
const {v4 : uuidv4} = require('uuid');
const{validationResult} = require('express-validator');
const HttpError = require('../model/http-error');
const {FlightDetail} = require('../model/flights')
const {Booking, Passenger }= require('../model/bookings')
const mongoose = require('mongoose');
const {Flight} = require('../model/flights')
const {Payment} = require('../model/bookings')


// Discount constants
const CHILD_DISCOUNT = 0.5;  // 50% off for passengers below 10 years
const SENIOR_DISCOUNT = 0.3; // 30% off for passengers above 60 years
const ADVANCE_BOOKING_DISCOUNT = 0.1; // 10% off if booked 15+ days in advance

// Helper function to reset time for date comparison
const resetTime = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

// Calculate discount based on passenger age
const calculateAgeDiscount = (age, basePrice) => {
  if (age < 10) return basePrice * (1 - CHILD_DISCOUNT);
  if (age > 60) return basePrice * (1 - SENIOR_DISCOUNT);
  return basePrice;
};

// Check if journey date is 15+ days from today
const isAdvanceBooking = (journeyDate) => {
  const today = resetTime(new Date());
  const journey = resetTime(journeyDate);
  const diffDays = Math.ceil((journey - today) / (1000 * 60 * 60 * 24));
  return diffDays >= 15;
};

// Booking Logic
exports.bookTicket = async (req, res) => {
  try {
      // Log the incoming request body
      console.log('Booking Request Body:', req.body);

      const { user_id, journeyDate, passengers, total_price, classType } = req.body;
      const { flightId } = req.params;  // Getting flightId from the URL parameter

      // Basic validation for required fields
      if (!user_id) {
          return res.status(400).json({ message: 'User ID is required' });
      }
      if (!flightId) {
          return res.status(400).json({ message: 'Flight ID is required' });
      }
      if (!journeyDate || isNaN(new Date(journeyDate).getTime())) {
          return res.status(400).json({ message: 'Invalid journey date format' });
      }
      if (!classType) {
          return res.status(400).json({ message: 'Class type is required' });
      }
      if (!passengers || passengers.length === 0) {
          return res.status(400).json({ message: 'At least one passenger is required' });
      }

      // Check if the flight exists
      const flight = await Flight.findById(flightId);
      if (!flight) {
          return res.status(404).json({ message: 'Flight not found' });
      }

      // Create the booking document
      const newBooking = new Booking({
          user_id,
          flight_id: flightId,
          journeyDate,
          passengers,
          total_price,
          classType,
      });

      // Save the booking to the database
      await newBooking.save();

      // Send a success response
      res.status(201).json({
          message: 'Booking confirmed!',
          booking: newBooking,
      });
  } catch (error) {
      console.error('Error during booking:', error);
      res.status(500).json({
          message: 'Failed to book ticket',
          error: error.message,
      });
  }
};
