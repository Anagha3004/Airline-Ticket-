const express = require('express');
const httpError  = require('../model/http-error');
const {v4 : uuidv4} = require('uuid');
const HttpError = require('../model/http-error');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');




const { User, Role, ServiceProvider } = require('../model/User');



//get all users
const getUsers = async (req,res,next)=>{
    let getUsers;
    try{
        getUsers = await User.find({}, '-password'); 
    }catch(err){
        const error = new HttpError('No users found...',500);
        return next(error);
    }
    res.status(200).json({getUsers: getUsers.map(user=>user.toObject({getters:true}))})

}



//signup
const signup = async (req, res, next) => {
    const { name, email, password, mobile, role } = req.body;

    try {
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return next(new HttpError('User already exists! Please login.', 422));
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12);

        // Assign role and generate serviceCode if the user is a service provider
        let userRole = await Role.findOne({ role });
        if (!userRole) {
            return next(new HttpError('Role not found!', 500));
        }

        // Generate unique serviceCode only for service providers
        let serviceCode;
        if (role === 'serviceprovider') {
            serviceCode = `SP${Math.floor(Math.random() * 1000000)}`; // Example: SP123456
        }

        const createdUser = new User({
            name,
            email,
            password: hashedPassword,
            mobile,
            image: 'https://example.com/default-profile.jpg', // Default profile image
            roleId: userRole._id,
        });

        await createdUser.save();

        res.status(201).json({ message: 'User created successfully!', user: createdUser.toObject({ getters: true }) });
    } catch (err) {
        console.error(err);
        return next(new HttpError('Signing up failed, please try again.', 500));
    }
};

const ADMIN_EMAIL = 'admin@gmail.com';
const ADMIN_PASSWORD = 'admin123';

// const login = async (req, res, next) => {
//     const { email, password, serviceCode } = req.body;

//     try {
//         // Check if admin credentials match
//         if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
//             return res.status(200).json({
//                 message: 'Admin logged in successfully!',
//                 role: 'admin'
//             });
//         }

//         // Check for existing service provider
//         const serviceProvider = await ServiceProvider.findOne({ email }).populate('roleId');
//         if (serviceProvider) {
//             const isValidPassword = await bcrypt.compare(password, serviceProvider.password);
//             if (!isValidPassword || (serviceCode && serviceProvider.serviceCode !== serviceCode)) {
//                 return next(new HttpError('Invalid service provider credentials!', 401));
//             }
//             return res.status(200).json({
//                 message: 'Service provider logged in successfully!',
//                 user: serviceProvider.toObject({ getters: true })
//             });
//         }

//         // Check for existing user (customer)
//         const customer = await User.findOne({ email }).populate('roleId');
//         if (!customer) {
//             return next(new HttpError('Invalid credentials!', 401));
//         }

//         const isValidPasswordForCustomer = await bcrypt.compare(password, customer.password);
//         if (!isValidPasswordForCustomer) {
//             return next(new HttpError('Invalid credentials!', 401));
//         }

//         return res.status(200).json({
//             message: 'Customer logged in successfully!',
//             user: customer.toObject({ getters: true })
//         });
//     } catch (err) {
//         console.error(err);
//         return next(new HttpError('Login failed, please try again.', 500));
//     }
// };
const login = async (req, res, next) => {
    const { email, password, serviceCode } = req.body;

    try {
        // Check if admin credentials match
        if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
            return res.status(200).json({
                message: 'Admin logged in successfully!',
                role: 'admin',
                userId: 'admin_id'
            });
        }

        // Check for existing service provider
        const serviceProvider = await ServiceProvider.findOne({ email }).populate('roleId');
        if (serviceProvider) {
            const isValidPassword = await bcrypt.compare(password, serviceProvider.password);
            if (!isValidPassword) {
                return next(new HttpError('Invalid credentials!', 401));
            }

            // Ensure serviceCode is provided and matches
            if (!serviceCode || serviceProvider.serviceCode !== serviceCode) {
                return next(new HttpError('Invalid service code for service provider login!', 401));
            }

            return res.status(200).json({
                message: 'Service provider logged in successfully!',
                role: 'serviceProvider',
                userId: serviceProvider._id.toString(),
                serviceCode: serviceProvider.serviceCode
            });
        }

        // Check for existing user (customer)
        const customer = await User.findOne({ email }).populate('roleId');
        if (!customer) {
            return next(new HttpError('Invalid credentials!', 401));
        }

        const isValidPasswordForCustomer = await bcrypt.compare(password, customer.password);
        if (!isValidPasswordForCustomer) {
            return next(new HttpError('Invalid credentials!', 401));
        }

        return res.status(200).json({
            message: 'Customer logged in successfully!',
            role: 'customer',
            userId: customer._id.toString()
        });
        
    } catch (err) {
        console.error(err);
        return next(new HttpError('Login failed, please try again.', 500));
    }
};


const createServiceProvider = async (req, res, next) => {
    const { name, email, password, mobile } = req.body;

    try {
        // Check if user already exists
        const existingUser = await ServiceProvider.findOne({ email });
        if (existingUser) {
            return next(new HttpError('Service provider already exists! Please login.', 422));
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 12);

        // Find the service provider role
        const userRole = await Role.findOne({ role: 'serviceprovider' });
        if (!userRole) {
            return next(new HttpError('Service provider role not found!', 500));
        }

        // Generate unique service code
        let serviceCode;
        let isUnique = false;

        while (!isUnique) {
            serviceCode = `SP${Math.floor(Math.random() * 1000000)}`; // Example: SP123456
            const existingCode = await ServiceProvider.findOne({ serviceCode });
            isUnique = !existingCode; // Check if the code is unique
        }

        // Create new service provider user
        const createdUser = new ServiceProvider({
            name,
            email,
            password: hashedPassword,
            mobile,
            image: 'https://example.com/default-profile.jpg', // Default profile image
            roleId: userRole._id,
            serviceCode
        });

        await createdUser.save();

        res.status(201).json({
            message: 'Service provider created successfully!',
            user: createdUser.toObject({ getters: true })
        });
    } catch (err) {
        console.error(err);
        return next(new HttpError('Creating service provider failed, please try again.', 500));
    }
};

const deleteServiceProvider = async (req, res, next) => {
    const { id } = req.params; // Assuming the ID is passed in the request URL

    try {
        // Delete the service provider by ID
        const serviceProvider = await ServiceProvider.findByIdAndDelete(id);

        if (!serviceProvider) {
            return next(new HttpError('Service provider not found!', 404));
        }

        res.status(200).json({
            message: 'Service provider deleted successfully!',
        });
    } catch (err) {
        console.error(err);
        return next(new HttpError('Deleting service provider failed, please try again.', 500));
    }
};


const getServiceProviders = async (req, res, next) => {
    let serviceProviders;
    try {
        // Fetch all service providers
        serviceProviders = await ServiceProvider.find(); // Adjust the query if needed (e.g., with filtering)
    } catch (err) {
        const error = new HttpError('Fetching service providers failed, please try again.',500);
        return next(error);
    }
    res.status(200).json({serviceProviders: serviceProviders.map(serviceProviders=>serviceProviders.toObject({getters:true}))})

};



exports.getServiceProviders = getServiceProviders;
exports.createServiceProvider = createServiceProvider;
exports.deleteServiceProvider = deleteServiceProvider;
exports.getUsers = getUsers;
exports.signup = signup;
exports.login = login;