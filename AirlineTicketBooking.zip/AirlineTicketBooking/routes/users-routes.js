const express = require('express');
const HttpError = require('../model/http-error');

const router = express.Router();

const fileUpload  = require('../middleware/file-upload')

const usercontroller = require('../controllers/users-controllers');


router.get('/', usercontroller.getUsers);
router.post('/signup', fileUpload.single('image'), usercontroller.signup);
router.post('/login',usercontroller.login);
router.post('/newsp', fileUpload.single('image'), usercontroller.createServiceProvider);
router.delete('/deleteserviceprovider/:id', usercontroller.deleteServiceProvider);
router.get('/serviceproviders', usercontroller.getServiceProviders);





module.exports = router
