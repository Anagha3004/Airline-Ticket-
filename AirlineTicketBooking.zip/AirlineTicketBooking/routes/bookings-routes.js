const express = require('express')
const HttpError = require('../model/http-error')

//create a router object to handle routes or path
const router = express.Router();

//import  flightcontroller
const bookingcontroller = require('../controllers/bookings-controllers')
const {check} = require('express-validator')
const fileUpload = require('../middleware/file-upload')

// router.post('/bookflight', bookingcontroller.bookFlight)
router.post('/bookticket/:flightId', bookingcontroller.bookTicket);


module.exports = router