const express = require('express')
const HttpError = require('../model/http-error')

//create a router object to handle routes or path
const router = express.Router();

//import  flightcontroller
const flightcontroller = require('../controllers/flights-controllers')
const {check} = require('express-validator')
const fileUpload = require('../middleware/file-upload')
const checkAuth = require('../middleware/checkAuth');

router.get('/allflights', flightcontroller.getAllFlights);
router.get('/allflightsdetails', flightcontroller.getAllFlightDetails);

//get flight by flightid
router.get('/:fid',flightcontroller.getFlightById);

// post 
router.post('/', [
    check('name').not().isEmpty(),
    check('airline_id').notEmpty().withMessage('Airline ID is required.'),
    check('departure_airport').isLength({ min: 3 }),
    check('arrival_airport').isLength({ min: 3 }),
    check('departure_time').notEmpty().withMessage('Time is required.'),
    check('arrival_time').notEmpty().withMessage('Time is required.'),
    check('travel_duration').notEmpty().withMessage('Travel duration is required.')
], flightcontroller.createFlight);



//update or patch
router.patch('/:fid',flightcontroller.updateFlight);

//delete
router.delete('/:fid',flightcontroller.deleteFlight);

router.post(
    '/createAirline',
    [
        check('id').isNumeric().withMessage('ID must be a number'),
        check('name').not().isEmpty().withMessage('Name is required')
    ],
    flightcontroller.createAirline
);

router.post('/flight-detail', flightcontroller.createFlightDetail);
router.patch('/flight-detail/:fid', flightcontroller.updateFlightDetail);

// Route to get the airline and its flights
router.post('/airlineAndFlights', flightcontroller.getAirlineAndFlights);

// Route to add a flight to an airline
router.post('/addFlight', flightcontroller.createFlight);

router.get('/airlineflightlist/:airlineId', flightcontroller.getFlightsByAirlineId);

router.patch('/:id', flightcontroller.updateFlightById);
router.delete('/:id', flightcontroller.deleteFlightById);
// router.get('/search', flightcontroller.searchFlights);
// cd   


module.exports = router;