const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Role Schema
const roleSchema = new Schema({
    role: { type: String, required: true }
});

// User Schema
const userSchema = new Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, minlength: 6 },
    mobile: { type: Number, required: true },
    image: { type: String, required: true },
    roleId: { type: mongoose.Types.ObjectId, ref: 'Role', required: true },
});

const serviceproviderSchema = new Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true, minlength: 6 },
    mobile: { type: Number, required: true },
    image: { type: String, required: true },
    roleId: { type: mongoose.Types.ObjectId, ref: 'Role', required: true },
    serviceCode: { type: String, unique:true, }
});

const Role = mongoose.model('Role', roleSchema);
const User = mongoose.model('User', userSchema);
const ServiceProvider = mongoose.model('ServiceProvider', serviceproviderSchema);

module.exports = { Role, User, ServiceProvider};
