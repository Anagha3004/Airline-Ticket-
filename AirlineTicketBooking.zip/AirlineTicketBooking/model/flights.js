const mongoose=require('mongoose');
const Schema=mongoose.Schema;



const airlineschema=new Schema({
    id: {type:Number,required:true},
    name: {type:String,required:true},
    serviceCode: { type:String, required: true },
    
    flights: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Flight', required: true }]
    
});

const flightschema = new Schema({
    name: { type: String, required: true },
    airline_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Airline', required: true },
    departure_airport: { type: String, required: true },
    arrival_airport: { type: String, required: true },
    departure_time: { type: Date, required: true },
    arrival_time: { type: Date, required: true },
    travel_duration: { type: Number, required: true },
});


const flightdetailschema = new Schema({
   
    Flight_id: { type: Schema.Types.ObjectId, ref: 'Flight', required: true },
    Totalseats: { type: Number, required: true },
    economyseatprice: { type: Number, required: true },
    economyseatsavailable: { type: Number, required: true },
    firstclassseatprice: { type: Number, required: true },
    firstclassseatsavailable: { type: Number, required: true },
    businessseatprice: { type: Number, required: true },
    businessseatsavailable: { type: Number, required: true },
    discount: { type: Number, default: 0 }, 
    foodavailable: { type: String, enum: ['yes', 'no'], required: true },
    luggage: { type: Number, required: true }
    
});

module.exports = {
    Airline: mongoose.model('Airline', airlineschema),
    Flight: mongoose.model('Flight', flightschema),
    FlightDetail: mongoose.model('FlightDetail', flightdetailschema)
};