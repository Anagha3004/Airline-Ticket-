const mongoose=require('mongoose');
const Schema=mongoose.Schema;


// Passenger Schema (to store individual passenger details)
const passengerSchema = new Schema({
    name: { type: String, required: true },
    age: { type: Number, required: true },
    gender: { type: String, enum: ['male', 'female', 'other'], required: true }
  });
  
  // Booking Schema
  const bookingSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    flight_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Flight', required: true },
    classType: { type: String, enum: ['economy', 'firstClass', 'business'], required: true },
    passengerCount: { type: Number, required: false },
    passengers: [{ name: String, age: Number }],
    total_price: { type: Number, required: true },
    journeyDate: { type: Date, required: true },
  });
  

// const bookingschema=new Schema({
//     id: {type:Number,required:true},
//     user_id:{ type: Schema.Types.ObjectId, ref: 'User', required: true },
//     flight_id:{ type: Schema.Types.ObjectId, ref: 'Flight', required: true },
//     classType:{type:String,  enum: ['economy', 'firstClass', 'business'], required:true},
//     passengerCount:{type:Number,required:true},
//     total_price:{type:Number,required:true},
//     journeyon:{type:Date,required:true},
//     bookingDate:{type:Date,required:true}
    
// });

const paymentSchema = new mongoose.Schema({
    booking_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    amount: { type: Number, required: true },
    payment_date: { type: Date, default: Date.now },
    payment_method: { type: String, enum: ['credit card', 'debit card', 'net banking', 'UPI'], required: true },
    status: { type: String, enum: ['success', 'failed'], default: 'success' }
  });

module.exports = {
    Booking: mongoose.model('Booking', bookingSchema),
    Passenger: mongoose.model('Passenger', passengerSchema),
    Payment: mongoose.model('Payment', paymentSchema)
};