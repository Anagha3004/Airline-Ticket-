const jwt = require('jsonwebtoken');

// Middleware to check token
const authenticateToken = (req, res, next) => {
    const token = req.headers['authorization'] && req.headers['authorization'].split(' ')[1]; // Assumes Bearer token

    if (!token) return res.sendStatus(401); // No token provided

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403); // Invalid token
        req.user = user; // Save user info for the request
        next();
    });
};

module.exports = authenticateToken; // Export the middleware
