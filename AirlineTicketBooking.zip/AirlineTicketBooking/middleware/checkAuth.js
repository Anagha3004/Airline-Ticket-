const jwt = require('jsonwebtoken');
const HttpError = require('../model/http-error');

const checkAuth = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return next(new HttpError('Authentication failed, no token provided.', 401));
    }

    let decodedToken;
    try {
        decodedToken = jwt.verify(token, 'YOUR_SECRET_KEY'); // Replace with your actual secret key
    } catch (err) {
        return next(new HttpError('Authentication failed.', 401));
    }

    req.user = { id: decodedToken.userId, serviceCode: decodedToken.serviceCode }; // Ensure this matches your JWT structure
    next();
};

module.exports = checkAuth;


